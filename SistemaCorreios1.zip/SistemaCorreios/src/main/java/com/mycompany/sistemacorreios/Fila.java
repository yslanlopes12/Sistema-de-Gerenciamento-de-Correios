
package com.mycompany.sistemacorreios;

/**
 *
 * @author yslan
 */
    public class Fila<T> {
    Node<T> primeiro;
    private Node<T> ultimo;

    public Fila() {
        primeiro = null;
        ultimo = null;
    }
    public void adicionar(T item) {
        Node<T> novoNo = new Node<>(item);
        if (primeiro == null) {
            primeiro = novoNo;
            ultimo = novoNo;
        } else {
            ultimo.next = novoNo;
            ultimo = novoNo;
        }
    }

    public T remover() {
        if (primeiro == null) {
            return null;
        }
        T item = primeiro.data;
        primeiro = primeiro.next;
        return item;
    }

    public boolean estaVazia() {
        return primeiro == null;
    }

}
