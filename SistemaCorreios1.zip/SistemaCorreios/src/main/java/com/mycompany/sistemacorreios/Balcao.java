
package com.mycompany.sistemacorreios;

/**
 *
 * @author yslan
 */
    public class Balcao {
    Fila<Pacote> filaClientes;

    public Balcao() {
        filaClientes = new Fila<>();
    }

    public void adicionarPedido(Pacote pacote) {
        filaClientes.adicionar(pacote);
    }

    public void visualizarPedidos() { 
     System.out.println("_________________________________________");
       System.out.println("Pedidos no balcão:");
     
        Node<Pacote> atual = filaClientes.primeiro;
        while (atual != null) {
            Pacote pacote = atual.data;
            System.out.println("_________________________________________");
            System.out.println("Nome do Pacote: " + pacote.getNome());
            System.out.println("Descrição do Conteúdo: " + pacote.getDescricaoConteudo());
            System.out.println("Endereço de Destino: " + pacote.getEnderecoDestino());
            atual = atual.next;
        }
    }
}
