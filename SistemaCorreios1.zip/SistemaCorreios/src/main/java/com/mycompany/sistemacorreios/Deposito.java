
package com.mycompany.sistemacorreios;

/**
 *
 * @author yslan
 */
    public class Deposito {
    private Pilha<Pacote> pilhaPacotes;

    public Deposito() {
        pilhaPacotes = new Pilha<>();
    }

    public void processarEnviarPacotes() {
        while (!pilhaPacotes.estaVazia()) {
            Pacote pacote = pilhaPacotes.desempilhar();
            System.out.println("Enviando pacote para: " + pacote.getEnderecoDestino());
        }
    }

    public void adicionarPacote(Pacote pacote) {
        pilhaPacotes.empilhar(pacote);
    }

    public void visualizarPacotes() {
      System.out.println("_________________________________________");
        System.out.println("Pacotes no depósito:");
        Node<Pacote> atual = pilhaPacotes.topo;
        while (atual != null) {
            Pacote pacote = atual.data;
            System.out.println("_________________________________________");
            System.out.println("Nome do Pacote: " + pacote.getNome());
            System.out.println("Descrição do Conteúdo: " + pacote.getDescricaoConteudo());
            System.out.println("Endereço de Destino: " + pacote.getEnderecoDestino());
            atual = atual.next;
        }
    }
}
