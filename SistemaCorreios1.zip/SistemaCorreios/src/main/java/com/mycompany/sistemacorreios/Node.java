
package com.mycompany.sistemacorreios;

/**
 *
 * @author yslan
 */
// Nó para a lista encadeada
    public class Node<T> {
   
    T data;
    Node<T> next;

    public Node(T data) {
        this.data = data;
        this.next = null;
    }
}

