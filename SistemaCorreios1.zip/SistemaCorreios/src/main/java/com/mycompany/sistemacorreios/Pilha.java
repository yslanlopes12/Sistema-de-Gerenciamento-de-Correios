package com.mycompany.sistemacorreios;

/**
 *
 * @author yslan
 */
    public class Pilha<T> {

    Node<T> topo;

    public Pilha() {
        topo = null;
    }

    public void empilhar(T item) {
        Node<T> novoNo = new Node<>(item);
        if (topo == null) {
            topo = novoNo;
        } else {
            novoNo.next = topo;
            topo = novoNo;
        }
    }

    public T desempilhar() {
        if (topo == null) {
            return null;
        }
        T item = topo.data;
        topo = topo.next;
        return item;
    }

    public boolean estaVazia() {
        return topo == null;
    }
}
