
package com.mycompany.sistemacorreios;

/**
 *
 * @author yslan
 */
public class SistemaCorreios {
    public static void main(String[] args) {
        // Criando alguns pacotes
        Pacote pacote1 = new Pacote("Livro", "Livro de ficção científica", "Rua A, 123");
        Pacote pacote2 = new Pacote("Eletrônicos", "Smartphone e acessórios", "Rua B, 456");
        Pacote pacote3 = new Pacote("Eletrônica", "Smartphone e acessórios", "Rua B, 456");

        // Criando balcão e depósito
        Balcao balcao = new Balcao();
        Deposito deposito = new Deposito();

        // Adicionando pacotes ao balcão
        balcao.adicionarPedido(pacote1);
        balcao.adicionarPedido(pacote2);

        // Visualizando pedidos no balcão
        balcao.visualizarPedidos();

        // Atendendo e enviando pacotes para o depósito
        while (!balcao.filaClientes.estaVazia()) {
            Pacote pacote = balcao.filaClientes.remover();
            deposito.adicionarPacote(pacote);
        }

        // Visualizando pacotes no depósito
        deposito.visualizarPacotes();

        // Processando e enviando pacotes do depósito
        deposito.processarEnviarPacotes();
    }
}
