package com.mycompany.sistemacorreios;

/**
 *
 * @author yslan
 */
    public class Pacote {

    private String nome;
    private String descricaoConteudo;
    private String enderecoDestino;

    public Pacote(String nome, String descricaoConteudo, String enderecoDestino) {
        this.nome = nome;
        this.descricaoConteudo = descricaoConteudo;
        this.enderecoDestino = enderecoDestino;
    }

    public String getNome() {
        return nome;
    }

    public String getDescricaoConteudo() {
        return descricaoConteudo;
    }

    public String getEnderecoDestino() {
        return enderecoDestino;
    }
}
